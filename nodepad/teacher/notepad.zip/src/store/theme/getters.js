export default {
    getTheme(state)
    {
        //返回状态值给组件
        return state.theme;
    }
}