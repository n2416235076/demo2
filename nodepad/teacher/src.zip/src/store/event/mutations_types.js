//添加事件
export const ADDEVENT = 'ADDEVENT';

//完成事件
export const EVENTDONE = 'EVENTDONE';


//撤销已完成
export const EVENTTODO = 'EVENTTODO';


//取消
export const EVENTCANCEL = 'EVENTCANCEL';


//编辑数据
export const EDITEVENT = 'EDITEVENT';


//删除数据
export const DELEVENT = 'DELEVENT';


//清空
export const CLEAREVENT = 'CLEAREVENT';