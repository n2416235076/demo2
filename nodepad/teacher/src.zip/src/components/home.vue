<template>
  <div id="home">
    hello world
  </div>
</template>

<script>
  export default {
      name:"Home",
      data(){
        return {
          
        }
      }
  }
</script>
